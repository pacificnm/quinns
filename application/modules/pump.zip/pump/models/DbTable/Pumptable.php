<?php

class Pump_Model_DbTable_Pumptable extends Zend_Db_Table_Abstract
{

    protected $_name = 'pumptable';
    protected $_schema = 'quinn';

}

