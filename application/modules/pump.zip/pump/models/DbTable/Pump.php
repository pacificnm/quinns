<?php

class Pump_Model_DbTable_Pump extends Zend_Db_Table_Abstract
{

    protected $_name = 'pump';


}

