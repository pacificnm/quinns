<?php
/**
 * Pump Bootstrap class to bootstrap model
 *
 * @author ISS Jaimie Garner
 * @copyright 2013
 * @package Pump
 * @category Bootstrap
 * @version 1.0
 * @uses Zend_Application_Module_Bootstrap
 */


class Pump_Bootstrap extends Zend_Application_Module_Bootstrap
{


}

