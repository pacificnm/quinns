<?php
/**
 * Pump Controller class
 *
 * @author ISS Jaimie Garner
 * @copyright 2013
 * @package Pump
 * @category Controller
 * @version 1.0
 * @uses Zend_Controller_Action
 */


class Pump_AdminController extends Zend_Controller_Action
{

    /**
     * Init
     */
    public function init()
    {
    }

    /**
     * indexAction
     */
    public function indexAction()
    {
    }

    public function listAction()
    {
    	
    }

}

